package com.kush.kushdemo.utility.token;

import java.security.MessageDigest;

import javax.xml.bind.DatatypeConverter;
import static java.nio.charset.StandardCharsets.UTF_8;
import lombok.SneakyThrows;

public class HashGeneratorUtils {

	@SneakyThrows
    public static String generateHash(String seed, long expireTime, String hashAlgorithm) {
        String uniqueKey = seed + expireTime;

        byte[] encodedMessage =
                MessageDigest.getInstance(hashAlgorithm).digest(uniqueKey.getBytes(UTF_8));

        return DatatypeConverter.printHexBinary(encodedMessage) + "_" + expireTime;
    }
}
