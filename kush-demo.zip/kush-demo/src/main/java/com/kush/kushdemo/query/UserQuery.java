package com.kush.kushdemo.query;

import java.util.List;

import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.kush.kushdemo.entity.User;
import com.kush.kushdemo.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class UserQuery implements GraphQLQueryResolver {

	private UserService userService;
	
	public UserQuery(UserService userService) {
		this.userService = userService;
	}
	
	public List<User> getAllUsers() {
		log.info("Retrieving all users from db");
		return userService.getAllUsers().collectList().block();
	}
}
