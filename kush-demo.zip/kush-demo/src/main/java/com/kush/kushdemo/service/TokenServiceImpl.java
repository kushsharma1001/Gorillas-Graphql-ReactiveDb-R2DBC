package com.kush.kushdemo.service;

import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Service;

import com.kush.kushdemo.utility.constants.Constants;
import com.kush.kushdemo.utility.token.HashGeneratorUtils;

@Service
public class TokenServiceImpl implements TokenService {

	@Override
	public String fetchToken(final String username) {
		return HashGeneratorUtils.generateHash(username, addSecondsToCurrentTimeIInMilliSeconds(Constants.FIVE_MINUTES_IN_SEC), Constants.HASH_ALGORITHM);
	}
	
	public long addSecondsToCurrentTimeIInMilliSeconds(long seconds) {
        return System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(seconds);
    }
}
