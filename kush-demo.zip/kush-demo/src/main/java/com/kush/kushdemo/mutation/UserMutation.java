package com.kush.kushdemo.mutation;

import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.kush.kushdemo.service.TokenService;
import com.kush.kushdemo.service.UserService;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Component
@Slf4j
public class UserMutation implements GraphQLMutationResolver {

	private UserService userService;
	private TokenService tokenService;
	
	public UserMutation(UserService userService, TokenService tokenService) {
		this.userService = userService;
		this.tokenService = tokenService;
	}

	public String fetchToken(String username, String password) {
		log.info("Validating user existence");

		Mono<Boolean> userExists = userService.userExists(username, password);
		
		if (userExists.block()) {
			log.info("Fetching token");
			return tokenService.fetchToken(username);
		}
		return "Oops! You are not registered with us!";
		}

}
