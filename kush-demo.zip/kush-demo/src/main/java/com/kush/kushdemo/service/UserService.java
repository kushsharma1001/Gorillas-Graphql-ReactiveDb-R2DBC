package com.kush.kushdemo.service;

import com.kush.kushdemo.entity.User;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface UserService {

	Flux<User> saveUsers(Flux<User> users);

	Flux<User> getAllUsers();

	Mono<Boolean> userExists(String username, String password);
}
