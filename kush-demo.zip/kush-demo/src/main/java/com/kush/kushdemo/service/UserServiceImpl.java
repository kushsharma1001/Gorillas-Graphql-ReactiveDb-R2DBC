package com.kush.kushdemo.service;

import org.springframework.stereotype.Service;

import com.kush.kushdemo.entity.User;
import com.kush.kushdemo.repository.UserRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class UserServiceImpl implements UserService {

	private UserRepository userRepository;
	
	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public Flux<User> saveUsers(Flux<User> users) {
		return userRepository.saveAll(users);
	}

	@Override
	public Flux<User> getAllUsers() {
		return userRepository.findAll();
	}
	
	@Override
	public Mono<Boolean> userExists(final String username, final String password) {
		return userRepository.existsByUsernameAndPassword(username, password);
	}
}
