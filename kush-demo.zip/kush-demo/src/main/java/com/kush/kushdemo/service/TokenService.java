package com.kush.kushdemo.service;

public interface TokenService {
	String fetchToken(final String username);
}
