package com.kush.kushdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.kush.kushdemo.service.UserService;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
public class KushDemoApplication {

	@Autowired
	private UserService userService;
	
	public static void main(String[] args) {
		SpringApplication.run(KushDemoApplication.class, args);
	}
}
