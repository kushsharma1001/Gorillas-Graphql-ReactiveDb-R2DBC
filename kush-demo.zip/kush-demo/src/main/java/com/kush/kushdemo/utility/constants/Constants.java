package com.kush.kushdemo.utility.constants;

public class Constants {

	public static final long FIVE_MINUTES_IN_SEC = 300L;
	public static final String HASH_ALGORITHM = "SHA-256";
}
