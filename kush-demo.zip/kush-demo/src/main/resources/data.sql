DELETE FROM user;
INSERT INTO  user (firstname, lastname, email, username, password) VALUES ('KUSH', 'SHARMA', 'k.s@xyz.com', 'ksharma', 'password123');
INSERT INTO  user (firstname, lastname, email, username, password) VALUES ('LUV', 'SHARMA', 'l.s@xyz.com', 'lsharma', 'password12345');