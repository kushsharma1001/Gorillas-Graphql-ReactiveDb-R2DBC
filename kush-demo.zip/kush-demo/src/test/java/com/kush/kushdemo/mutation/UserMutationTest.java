package com.kush.kushdemo.mutation;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.kush.kushdemo.mutation.UserMutation;
import com.kush.kushdemo.service.TokenService;
import com.kush.kushdemo.service.UserService;

@RunWith(PowerMockRunner.class)
class UserMutationTest {

	@InjectMocks
	UserMutation userMutation;
	
	@Mock
	UserService userService;
	@Mock
	TokenService tokenService;
	
	final String token = "AABBCCDDEEFFGGHH";
	final String tokenError = "Oops! You are not registered with us!";
	
	@BeforeEach
    public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void fetchToken() {
		
		String userName = "Kush";
		String password = "dummyPassword";
		//positive
		fetchTokenSuccess_RegisteredUser(userName, password);
		//negative
		fetchTokenError_NonRegisteredUser(userName, password);
	}

	private void fetchTokenSuccess_RegisteredUser(String userName, String password) {
		Mockito.doReturn(true).when(userService).userExists(userName, password);
		Mockito.doReturn(token).when(tokenService).fetchToken(userName);
		assertEquals(token, userMutation.fetchToken(userName, password));
	}
	
	private void fetchTokenError_NonRegisteredUser(String userName, String password) {
		Mockito.doReturn(false).when(userService).userExists(userName, password);
		Mockito.doReturn(tokenError).when(tokenService).fetchToken(userName);
		assertEquals(tokenError, userMutation.fetchToken(userName, password));
	}

}
