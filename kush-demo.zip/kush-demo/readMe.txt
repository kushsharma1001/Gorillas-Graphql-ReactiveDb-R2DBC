query {
  getAllUsers{
  	firstname
  	lastname 
  	email
  	username
  	password
  }
}

mutation {
  fetchToken(username: "Patton Down DeHatches", password:"DmFPPuM9")
}

mutation {
  fetchToken(username: "Kush", password:"12345")
}

Graphiql url: http://localhost:8080/graphiql
H2 url: http://localhost:8080/h2-console/